

import { GoogleGenAI } from "@google/genai";
import { ProjectData, FinancialResults } from "../types";

const parseProjectContext = (data: ProjectData, results: FinancialResults): string => {
  return `
    Nome do Projeto: ${data.projectName}
    Período: ${data.startDate} a ${data.endDate} (${results.durationDays} dias)
    Funcionários/Itens: ${results.totalEmployees}
    
    FINANCEIRO (Moeda: Euro €):
    - Receita Total: €${results.totalRevenue.toFixed(2)}
    - Custos Totais: €${results.totalCost.toFixed(2)}
    - Lucro Líquido: €${results.netProfit.toFixed(2)}
    - Margem de Lucro: ${results.marginPercent.toFixed(1)}%
    - ROI: ${results.roiPercent.toFixed(1)}%
    
    DETALHAMENTO DE CUSTOS:
    - Mão de Obra Direta (Horas Produzidas): €${results.servicesDirectCost.toFixed(2)}
    
    ENCARGOS TRABALHISTAS (Base Fixa €${results.baseSalary}/func):
    - TSU (23.75%): €${results.socialSecurityCost.toFixed(2)}
    - Seguro (1%): €${results.insuranceCost.toFixed(2)}
    - Subsídio Natal (13º): €${results.christmasBonusCost.toFixed(2)}
    
    LOGÍSTICA & OUTROS:
    - Alojamento: €${results.accommodationCost.toFixed(2)} (Detalhe: ${data.accommodations.map(a => `${a.name} (${a.type})`).join(', ')})
    - Transporte: €${results.transportCost.toFixed(2)} (Detalhe: ${(data.transports || []).map(t => `${t.name} (${t.type})`).join(', ')})
    - Frete EPIs: €${results.shippingCost.toFixed(2)}
    - Materiais/EPIs: €${results.materialCost.toFixed(2)}
    - Comissão Comercial (${data.commercialCommissionPercent}%): €${results.commissionCost.toFixed(2)}
  `;
};

export const analyzeProjectProfitability = async (data: ProjectData, results: FinancialResults): Promise<string> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      return "Erro: Chave da API ausente. Verifique a configuração do ambiente.";
    }

    const ai = new GoogleGenAI({ apiKey });
    const context = parseProjectContext(data, results);
    
    const prompt = `
      Você é um analista financeiro sênior de projetos baseados na Europa. Analise os seguintes dados de rentabilidade.
      
      DADOS:
      ${context}
      
      TAREFA:
      Forneça uma avaliação breve e profissional em Português, usando formato Markdown. Use o símbolo € para valores monetários.
      1. **Veredito de Rentabilidade**: Essa é uma margem saudável considerando a estrutura de custos?
      2. **Análise de Custos**: Avalie o peso dos encargos fixos e do alojamento na rentabilidade.
      3. **Estratégia de Otimização**: Sugira 2 maneiras específicas de melhorar a margem com base nesses números.
      
      Mantenha o tom objetivo e conciso. Use marcadores (bullet points).
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });

    return response.text || "Nenhuma análise gerada.";
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    return "Não foi possível gerar a análise neste momento. Tente novamente mais tarde.";
  }
};